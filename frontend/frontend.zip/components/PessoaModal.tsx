'use client';

import { useState, useEffect } from 'react';
import { X, Save, Loader2 } from 'lucide-react';
import { Pessoa, PessoaInput } from '@/lib/api';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

interface PessoaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: PessoaInput, id?: number) => Promise<void>;
  pessoa?: Pessoa | null;
}

export function PessoaModal({ isOpen, onClose, onSave, pessoa }: PessoaModalProps) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (pessoa) {
      setNome(pessoa.nome);
      setEmail(pessoa.email);
      // Format date for input type="date" (YYYY-MM-DD)
      const dateStr = pessoa.dataNascimento.split('T')[0];
      setDataNascimento(dateStr);
    } else {
      setNome('');
      setEmail('');
      setDataNascimento('');
    }
  }, [pessoa, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome || !email || !dataNascimento) {
      toast.error('Preencha todos os campos obrigatórios.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({ nome, email, dataNascimento }, pessoa?.id);
      onClose();
    } catch (error) {
      console.error(error);
      toast.error('Ocorreu um erro ao salvar os dados.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md bg-[#0a0c27] border border-[#1f2937] rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="flex items-center justify-between p-6 border-b border-[#1f2937]">
              <h2 className="text-xl font-semibold text-white">
                {pessoa ? 'Editar Pessoa' : 'Nova Pessoa'}
              </h2>
              <button
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-2">
                <label htmlFor="nome" className="text-sm font-medium text-gray-300">
                  Nome Completo
                </label>
                <input
                  id="nome"
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#050617] border border-[#1f2937] rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#00ca92] focus:border-transparent transition-all"
                  placeholder="João Silva"
                  required
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-gray-300">
                  E-mail
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#050617] border border-[#1f2937] rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#00ca92] focus:border-transparent transition-all"
                  placeholder="joao@exemplo.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="dataNascimento" className="text-sm font-medium text-gray-300">
                  Data de Nascimento
                </label>
                <input
                  id="dataNascimento"
                  type="date"
                  value={dataNascimento}
                  onChange={(e) => setDataNascimento(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#050617] border border-[#1f2937] rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#00ca92] focus:border-transparent transition-all [color-scheme:dark]"
                  required
                />
              </div>

              <div className="pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 text-sm font-medium text-gray-300 hover:text-white bg-transparent hover:bg-white/5 rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-[#050617] bg-[#00ca92] hover:bg-[#00cfbd] rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  {pessoa ? 'Atualizar' : 'Salvar'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
